package com.example.lernapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class LernappDbHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "Lernapp.db";
    public static final int DB_VERSION = 1;

    //Table Subjects
    public static final String TABLE_SUBJECT = "subject";
    public static final String SUBJECT_ID = "subject_id";
    public static final String COLUMN_SUBJECTNAME = "subjectname";
    public static final String COLUMNS_IMAGE = "image";

    public static final String SQL_CREATE_TABLESubject =
            "create table "+ TABLE_SUBJECT + "("+
                    SUBJECT_ID + " integer primary key, "+
                    COLUMN_SUBJECTNAME + " text not null, "+
                    COLUMNS_IMAGE+" text);";

    //Table Questions with Answer
    public static final String TABLE_Questions = "questions";
    public static final String COLUMN_ID_Q = "question_id";
    public static final String SUBJECT = "subject_id";
    public static final String COLUMN_QUESTION = "question_content";
    public static final String COLUMN_ANSWER = "answer";

    public static final String SQL_CREATE_TABLEQuestion =
            "create table "+ TABLE_Questions + "("+
                    COLUMN_ID_Q + " integer primary key autoincrement, "+
                    SUBJECT + " integer,"+
                    COLUMN_QUESTION + " text, "+
                    COLUMN_ANSWER+ " text," +
                    " FOREIGN KEY ("+SUBJECT+") REFERENCES "+TABLE_SUBJECT+"("+SUBJECT_ID+"));";


    public LernappDbHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLESubject);
        db.execSQL(SQL_CREATE_TABLEQuestion);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    //--------------------------------------------------Subject
    public boolean addSubject(Integer subjectid, String subjname, String image)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(SUBJECT_ID, subjectid);
        contentValues.put(COLUMN_SUBJECTNAME, subjname);
        contentValues.put(COLUMNS_IMAGE, image);

        long result = db.insert(TABLE_SUBJECT, null, contentValues);

        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    public Cursor showSubjects()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM "+TABLE_SUBJECT, null);
        return data;
    }

    //--------------------------------------------------Questions
    public boolean addQuestion(Integer subjectid, String question, String answer)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(SUBJECT, subjectid);
        contentValues.put(COLUMN_QUESTION, question);
        contentValues.put(COLUMN_ANSWER, answer);

        long result = db.insert(TABLE_Questions, null, contentValues);

        if(result==-1){
            return false;
        }else{
            return true;
        }

    }

    public Cursor showQuestions()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM "+TABLE_Questions, null);
        return data;
    }

    public Integer deleteQuestion(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_Questions,"question_id = ?", new String[] {id});
    }
}
