package com.example.lernapp;

import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class Page_2 extends Fragment {

    LernappDbHelper Db;

    Button button_create, button_view, button_delete;
    EditText subject, question, answer, questionid;

    //Constructor
    public Page_2(){};

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View PageTwo = inflater.inflate(R.layout.page2, container, false);

        Db = new LernappDbHelper(getContext());

        subject = (EditText) PageTwo.findViewById(R.id.subject_id);
        question = (EditText) PageTwo.findViewById(R.id.questionContent);
        answer = (EditText) PageTwo.findViewById(R.id.questionAnswer);
        questionid = (EditText) PageTwo.findViewById(R.id.questionID);


        button_create = (Button) PageTwo.findViewById(R.id.button_createQuestion);
        button_view = (Button) PageTwo.findViewById(R.id.button_viewQuestions);
        button_delete = (Button) PageTwo.findViewById(R.id.button_deleteQuestions);

        AddDataQuesttion();
        ViewDataQuestion();
        DeleteDataQuestion();

        return PageTwo;
    }

    public void AddDataQuesttion(){
        button_create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Integer subj = Integer.parseInt(subject.getText().toString());
                String q = question.getText().toString();
                String a = answer.getText().toString();


                boolean insertData = Db.addQuestion(subj, q, a );

                if(insertData == true){
                    Toast.makeText(getContext(), "Data successfully inserted", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getContext(),
                            "Something went wrong :(,", Toast.LENGTH_LONG).show();

                }
            }
        });
    }

    public void ViewDataQuestion(){
        button_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor data = Db.showQuestions();

                if(data.getCount() == 0){
                    display("Error", "No Data found.");
                    return;
                }

                StringBuffer buffer = new StringBuffer();
                while(data.moveToNext()){
                    buffer.append("Question ID: "+data.getString(0)+" \n");
                    buffer.append("Subject: "+data.getString(1)+" \n");
                    buffer.append("Content: "+data.getString(2)+" \n");
                    buffer.append("Answer: "+data.getString(3)+" \n");


                    display("All Stored Data:", buffer.toString());
                }
            }
        });
    }

    public void DeleteDataQuestion(){

        button_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int tmp = questionid.getText().toString().length();
                if(tmp > 0){
                    Integer deleteRow = Db.deleteQuestion(questionid.getText().toString());
                    if(deleteRow > 0){
                        Toast.makeText(getContext(),
                                "Successfully deleted", Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(getContext(),
                                "Something went wrong :(,", Toast.LENGTH_LONG).show();

                    }
                }else{
                    Toast.makeText(getContext(),
                            "You must enter an ID to delete", Toast.LENGTH_LONG).show();

                }
            }
        });
    }

    public void display(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}