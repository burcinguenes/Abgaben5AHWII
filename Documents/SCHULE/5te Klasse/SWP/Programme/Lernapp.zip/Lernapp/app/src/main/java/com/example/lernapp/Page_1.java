package com.example.lernapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class Page_1 extends Fragment {

    LernappDbHelper dbHelper;

    ArrayList<String> listSubjects;
    ArrayAdapter adapter;

    ListView subjectlist;

    //Constructor
    public Page_1(){};

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View PageOne = inflater.inflate(R.layout.page1, container, false);

        dbHelper = new LernappDbHelper(getContext());
        listSubjects = new ArrayList<>();

        subjectlist = PageOne.findViewById(R.id.subject_list); //

        viewSubjects();

        subjectlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String text = subjectlist.getItemAtPosition(position).toString();
                Toast.makeText(getContext(), ""+text, Toast.LENGTH_SHORT).show();
            }
        });

        Button button1 = (Button) PageOne.findViewById(R.id.button1);
       button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity().getApplicationContext(), Activity_Button1.class);
                startActivity(intent);
            }
        });


        return PageOne;
    }

    public void viewSubjects() {
        Cursor cursor = dbHelper.showSubjects();

        if(cursor.getCount() == 0){
            Toast.makeText(getContext(), "No data to show", Toast.LENGTH_SHORT).show();
        }else{
            while (cursor.moveToNext()){
                listSubjects.add(cursor.getString(1)); //Subject name
            }

            adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, listSubjects);
            subjectlist.setAdapter(adapter);

        }
    }
}
