package com.example.lernapp;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class Page_3 extends Fragment {

    LernappDbHelper subjectDb;

    Button button_create, buton_view;
    EditText subjnumber, subjname;

    //Constructor
    public Page_3(){};

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View PageThree = inflater.inflate(R.layout.page3, container, false);

        subjectDb = new LernappDbHelper(getContext());


        subjnumber = (EditText) PageThree.findViewById(R.id.subject_id);
        subjname = (EditText) PageThree.findViewById(R.id.subject_name);
        button_create = (Button) PageThree.findViewById(R.id.button_createQuestion);
        buton_view = (Button) PageThree.findViewById(R.id.button_viewSubjects);


        AddData();
        ViewData();


        return PageThree;
    }

    public void AddData(){
        button_create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Integer number = Integer.parseInt(subjnumber.getText().toString());
                String name = subjname.getText().toString();

                boolean insertData = subjectDb.addSubject(number, name, null);

                if(insertData == true){
                    Toast.makeText(getContext(), "Data successfully inserted", Toast.LENGTH_LONG).show();
                    Page_1 p1 = new Page_1();
                    p1.viewSubjects(); //Homepage updaten
                }else{
                    Toast.makeText(getContext(),
                            "Something went wrong :(,", Toast.LENGTH_LONG).show();

                }
            }
        });
    }

    public void ViewData(){
       buton_view.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Cursor data = subjectDb.showSubjects();

               if(data.getCount() == 0){
                   display("Error", "No Data found.");
                   return;
               }

               StringBuffer buffer = new StringBuffer();
               while(data.moveToNext()){
                   buffer.append("ID: "+data.getString(0)+" \n");
                   buffer.append("Subject name: "+data.getString(1)+" \n");

                   display("All Stored Data:", buffer.toString());
               }
           }
       });
    }

    public void display(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}